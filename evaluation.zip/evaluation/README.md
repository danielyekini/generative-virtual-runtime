# MotionScript compatibility evaluation

This directory is an isolated harness. It does not change the packages under `packages/`.

## Reproduce

From the repository root:

```bash
npx tsx evaluation/harness/run-pipeline.ts
npx tsx evaluation/harness/continue-diagnostic.ts
npx tsx evaluation/harness/drive-browser.ts
cd evaluation && npm install
node evaluation/harness/write-report.mjs
```

`drive-browser.ts` starts Vite on `127.0.0.1:5199` and headless Google Chrome with remote debugging on port 9333. It expects Chrome at `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome` and `lottie-web` 5.13.0, which the playground already depends on.

The report is `MotionScript_Animation_Compatibility_Report.md`. Each fixture section copies the production system report (`STATUS`, `COUNTS`, and every diagnostic line) and the round-trip line. Captures, scenes, MotionScript, and logs are under `evidence/`. Paths in the report are relative to this directory.

Inputs are read from the Downloads paths recorded in `evidence/manifest.json` and copied into `evidence/sources/` without modification.

The working tree had no commits when this run was captured. `evidence/environment.json` records the versions and the failed `git rev-parse HEAD`.
