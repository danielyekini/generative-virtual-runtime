import pathlib,hashlib,json
run=pathlib.Path('docs/evaluations')/pathlib.Path('work/current-run').read_text();result=json.loads(pathlib.Path('evaluation/evidence/results.json').read_text()); records=[]
for f in result['fixtures']:
 sceneDir=pathlib.Path('evaluation/evidence/fixtures')/f['id'];files=[]
 for p in sorted(sceneDir.iterdir()):
  if p.is_file() and (p.suffix=='.motion' or p.name in ['imported-scene.json','compiled-scene.json']):files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 records.append({'id':f['id'],'format':f['format'],'sourcePath':f['sourcePath'],'sourceBytes':f['sourceBytes'],'sourceSha256':f['sha256'],'revision':None,'parentRevision':None,'canonicalStatus':'UNREGISTERED_SCRATCH','artifacts':files,'provenance':f['provenance']})
(run/'evidence/attempt-1/program-identities.json').write_text(json.dumps(records,indent=2)+'\n')
