import {spawn} from 'node:child_process';import {mkdtempSync,readFileSync,writeFileSync,mkdirSync} from 'node:fs';import {tmpdir} from 'node:os';import {join,resolve} from 'node:path';import {setTimeout as delay} from 'node:timers/promises';import {createRequire} from 'node:module';
import {Cdp} from '../evaluation/harness/cdp';import {checkVisualFrame} from '../evaluation/harness/visual-gate';
const require=createRequire(import.meta.url),{PNG}=require('../evaluation/node_modules/pngjs');
const run=readFileSync('work/current-run','utf8');const dir=resolve('docs/evaluations',run,'evidence/raster-counterfactual');mkdirSync(dir,{recursive:true});
const chrome=spawn('/usr/bin/chromium',['--headless=new','--disable-gpu','--force-device-scale-factor=1','--remote-debugging-port=9444','--user-data-dir='+mkdtempSync(join(tmpdir(),'gvr-trim-')),'--no-first-run','about:blank'],{stdio:['ignore','ignore','pipe']});let log='';chrome.stderr.on('data',x=>log+=x.toString());let socket:WebSocket|undefined;
try {
 let ws='';for(let i=0;i<100;i++){try{ws=(await(await fetch('http://127.0.0.1:9444/json/version')).json()).webSocketDebuggerUrl;if(ws)break;}catch{}await delay(100);}
 socket=new WebSocket(ws);await new Promise<void>((r,j)=>{socket!.addEventListener('open',()=>r());socket!.addEventListener('error',()=>j(new Error('socket')))});const cdp=new Cdp(socket);
 const {targetId}=await cdp.send('Target.createTarget',{url:'http://127.0.0.1:5199/'});const {sessionId}=await cdp.send('Target.attachToTarget',{targetId,flatten:true});
 const evaluate=async(code:string)=>{const r=await cdp.send('Runtime.evaluate',{expression:code,awaitPromise:true,returnByValue:true},sessionId);if(r.exceptionDetails)throw new Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 for(let i=0;i<100;i++){if(await evaluate('Boolean(window.__ready)'))break;await delay(100);}
 await evaluate(`window.prepare('LOT-01-imported')`);
 const output:any[]=[];const jobs=JSON.parse(readFileSync('evaluation/evidence/render-jobs.json','utf8')).jobs;const job=jobs.find((j:any)=>j.id==='LOT-01-imported');const settings=JSON.parse(readFileSync('evaluation/gate-settings.json','utf8'));
 for(const mode of ['original','sourceorder','immediate']) {
  if(mode==='sourceorder') await evaluate(`(async()=>{const {CanvasRenderer}=await import('/@fs${resolve('packages/canvas-renderer/src/index.ts')}');const source=await(await fetch('/sources/LOT-01.json')).json();const order=new Map(source.assets[0].layers.map((l,i)=>[l.ind,i]));const old=CanvasRenderer.prototype.render;CanvasRenderer.prototype.render=function(frame){const rank=d=>{const all=[...d.nodeId.matchAll(/layer_(\\d+)/g)];return order.get(Number(all.at(-1)?.[1]))??-1;};frame.drawItems.sort((a,b)=>rank(b)-rank(a));return old.call(this,frame);};return true;})()`);
  if(mode==='immediate') await evaluate('window.Path2D=undefined;true');
  for(const frame of [3,15,26,30,60]) {
   const id='frame_'+String(frame).padStart(5,'0');const index=job.samples.findIndex((s:any)=>s.id===id);await evaluate(`window.seek('native',${index})`);const data=await evaluate('window.nativePNG()');const png=Buffer.from(data.split(',')[1],'base64');writeFileSync(join(dir,`${mode}-${id}.png`),png);const native=PNG.sync.read(png),ref=PNG.sync.read(readFileSync(`evaluation/evidence/captures/LOT-01-imported/${id}-reference.png`));const live=PNG.sync.read(readFileSync(`evaluation/evidence/captures/LOT-01-imported/${id}-native.png`));output.push({mode,id,originalMatchesCapture:mode==='original'?native.data.equals(live.data):null,gate:checkVisualFrame(ref,native,settings.visualCertification,settings.pixel.inspectionThreshold)});
  }
 }
 writeFileSync(join(dir,'results.json'),JSON.stringify({method:'Diagnostic source-order and Path2D versus immediate-path raster counterfactual; references are exact saved source frames from active pinned full-window run. Original native raster must match before attributing changes. Source array order replaces hierarchy paint order; geometry/matrices/styles are untouched. No shared implementation changed.',output},null,2));console.log(output.map(x=>({mode:x.mode,id:x.id,matches:x.originalMatchesCapture,hot:x.gate.fractionBeyond,local:x.gate.maxLocalFractionBeyond})));
} finally {writeFileSync(join(dir,'chrome-log.txt'),log);socket?.close();chrome.kill('SIGTERM');}
