import pathlib,json,subprocess,hashlib,tarfile,datetime,sys
root=pathlib.Path('.').resolve();run=root/'docs/evaluations'/pathlib.Path('work/current-run').read_text();d=run/'source-snapshot';d.mkdir(exist_ok=True);stage=sys.argv[1]
if stage=='initial':
 archive=d/'initial-source.tar.gz'
 subprocess.run(['git','archive','--format=tar.gz','-o',str(archive),'HEAD'],check=True)
 files=[]
 with tarfile.open(archive) as tar:
  for entry in tar:
   if entry.isfile():files.append({'path':entry.name,'bytes':entry.size,'sha256':hashlib.sha256(tar.extractfile(entry).read()).hexdigest()})
else:
 paths=[]
 for p in root.rglob('*'):
  rel=p.relative_to(root)
  if not p.is_file() or p.is_symlink():continue
  parts=rel.parts
  if any(x in parts for x in ['.git','node_modules','.vite','dist','captures','source-snapshot']):continue
  if str(rel).startswith('evaluation/evidence/') or p.is_relative_to(run):continue
  if parts[0]=='work' and p.suffix not in ['.py','.ts','.md']:continue
  if p.name.startswith('.env') or p.suffix in ['.pem','.key'] or p.name in ['credentials','auth.json']:continue
  paths.append((str(rel),p))
 files=[]
 with tarfile.open(d/(stage+'-source.tar.gz'),'w:gz') as tar:
  for rel,p in sorted(paths):
   data=p.read_bytes();files.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});tar.add(p,arcname=rel,recursive=False)
(d/(stage+'-files.json')).write_text(json.dumps(files,indent=2)+'\n')
(d/(stage+'-working-tree.patch')).write_bytes(subprocess.check_output(['git','diff','--binary','HEAD']))
(d/(stage+'-git-status.txt')).write_bytes(subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all']))
(d/(stage+'-archive.json')).write_text(json.dumps({'archive':stage+'-source.tar.gz','sha256':hashlib.sha256((d/(stage+'-source.tar.gz')).read_bytes()).hexdigest(),'files':len(files),'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exclusions':['credentials','disposable dependencies/builds','capture evidence (retained separately)','historical and current recursive snapshots','current reporting directory'], 'initialNote':'Initial tracked source matches clean HEAD; measurement scripts retained separately in evidence.' if stage=='initial' else None},indent=2)+'\n');print(stage,len(files))
