Unevaluated implementation retrospective. These observations and proposals do not establish adopted capabilities or released support.

## 1. Result and fidelity

### What matches the director’s intent

Interactive **surface** (not a closed film): navy blueprint chrome, dominant drawing, Plan / Cutaway / Fit / Reset, room info panel, revisable assumptions strip, and the exact disclaimer **Concept only — not for construction**.

Layout: 12 × 10 m single-storey concept with entrance at the front, three bedrooms along the east side, open kitchen/dining/living to the rear garden, family bath, separate WC, utility, hall and corridor circulation that does not pass through bedrooms. Orthographic plan and oblique cutaway share the same metre→px scale (36 px/m) and room coordinates.

Intro sequence **From plan to house** (relative to program start ≈ “first ready to view”):

| Beat | Directed | Inspected |
| --- | --- | --- |
| 0–1600 ms | Trace footprint → partitions; labels & overall dims | CanvasRenderer stills `still-0s.png`, `still-0_7s.png`, `still-1_6s.png`: cyan exterior trim, white partitions, “Kitchen / Dining / Living”, “Bedrooms”, 12.0 m / 10.0 m |
| 1600–3400 ms | Raise walls; near wall lowered; ease to elevated framing | `still-2_5s.png`, `still-3_4s.png`: parallelogram wall extrusions; front wall shorter; `World` scale/position framing (chrome stays fixed) |
| 3400–4700 ms | Furnishings + controls | `still-4s.png`, `still-4_7s.png`, `still-8s.png`: furniture/fixtures, “Open living” / “Bed 1”, control hint text; Cutaway control emphasised |

Final authored state: furnished cutaway for inspection; **Plan** is one click away. Runtime checks at 5000 ms: Plan/Cutaway group opacity inheritance, Bedroom 1 highlight + info copy, Fit resets pan/zoom, Revise size toggles footprint assumption string.

### Approximations (visible consequences)

1. **Cutaway “elevation”** is hand-authored oblique 2D extrusion (`scale.y` on wall polygons), not `space.planar25d`. Near-facing wall is shorter, but the view is not a true three-quarter perspective camera. Needed because animated spatial camera/hinge channels are outside released `space.planar25d`.
2. **Pan/zoom**: `dragTranslate` + wheel/`+/-`/`=` scale on `World.Drawing`; zoom is uniform step about the drawing origin, **not** pinch or wheel-about-pointer. Multi-pointer/pinch is out of scope for `input.bindings`.
3. **Room select vs pan**: host click/drag threshold (E007, 4 logical units) applies per target. Pan starts on empty slab/floor; dragging that begins on a room hit target does not pan (room has no `dragTranslate`). Not a single-target threshold distinguishing both gestures on one geometry.
4. **Editable assumptions**: free text entry is unsupported. **Revise size** toggles between two authored footprint strings (12×10 vs 12×11 alt).
5. **Narrow / responsive**: single authored viewport 1280×900 with drawing above and controls/info beneath (stacked). No viewport-query or reflow capability; host letterboxing only.
6. **Reduced motion / interrupt**: no `prefers-reduced-motion` or cancel-timeline binding. Closest host behaviours: seek ≥ 4700 ms (complete cutaway + Plan control) or pause; interrupted intro tracks are **not** cancelled by the program.
7. **Door swings / fixtures**: schematic polylines and rectangles; not construction detailing.
8. **Sequence trigger**: runs from t=0 of the program clock (assumed “first ready”), not a separate host “concept ready” event.

### Wrong, unsupported, or unverified

- Pinch-to-zoom about gesture centre: **unsupported** (registry: multi-pointer out of scope).
- Wheel zoom about pointer: **unsupported** (wheel steps scale on the target; no pivot).
- Native reduced-motion branch and onInterrupt cancel: **unsupported** in language; **unverified** as host policies.
- Visible keyboard focus ring: focusable targets + tabIndex present; **focus chrome rendering not inspected** in stills (still captures are non-interactive screenshots).
- Continuous pan/zoom gesture feel and mobile pinch: **not** exercised in Chromium CDP stills; only InputSession click/Fit/Revise unit checks.
- Playground UI paste path: source compiles with the same `compileMotionScript` the playground author activity uses; **no** live Studio UI session was driven in this run.
- Seeking/loop at duration end beyond fill-forwards visual hold: duration 30 s with fill forwards; behaviour after 30 s depends on host clock (not separately tested).

### Material design assumptions

- External footprint exactly 12.0 × 10.0 m; wall thickness represented by stroke weight, not separate cavity geometry.
- Bedroom strip on the **east**; open living on the west/rear; corridor between living and bedrooms.
- Indicative internal sizes as labelled (e.g. living 6.8×4.2 m, beds ~3.4×3.0–3.3 m).
- Front = bottom of drawing; rear garden = top.
- Intro is the only automatic sequence; inspection is persistent via interactions afterward.

### Baseline measurements and provenance

| Item | Value |
| --- | --- |
| Repository commit | `a4d84b189ad4d533f1c4523c5a999cc22b594919` |
| MotionScript release | 0.26.0 (wire `"0.2"`) |
| Scene IR release | 0.25.0 |
| Capability pins used | `geometry.animatedTrim`, `geometry.trimPath`, `geometry.operators`, `geometry.roundedRect`, `input.bindings`, `text.basic`, `easing.hold` |
| Packages | compiler 0.1.22, runtime 0.1.27, canvas-renderer 0.1.5, schema 0.1.25 |
| Program | 2032 lines, 58910 bytes, SHA-256 `fbcf9a56623c6c2fcd7317c5939ca36941f46fbf45def8764c054eda895fd165` |
| Nodes / tracks / steps / key values | 184 / 38 / 0 / 76 |
| Interactions | 27 targets |
| Compile time | 68.9 ms (Node `compileMotionScript`, one run) |
| Evaluation | 0.217 ms/frame mean over 40×13 times on AnimationRuntime (Node, arm64) |
| Render | CanvasRenderer in headless Google Chrome 157.0.8103.38 via CDP; viewport 1280×900, DPR 1 |
| Authored effort | Not instrumented (estimate omitted) |

Verification commands (scratch; not in ZIP):

```text
node --import tsx /tmp/gvr-house-concept-blueprint/scratch/verify.mts
```

Results: compile ok, `validateSceneIR` ok, interaction log as above, stills written under `/tmp/gvr-house-concept-blueprint/verify/still-*.png` for times 0, 0.7, 1.6, 2.5, 3.4, 4.0, 4.7, 8.0 s. Full repository `npm run verify` **not** run (standalone artefact scope).

Limits vs DEFAULT_LIMITS: nodes 184/2000, tracks 38/1000, steps 0/1000, duration 30000/60000 ms, source ≪ 4 MiB. No limit workarounds required.

---

## 2. Hardest and most error-prone aspects (ranked)

1. **Exclusive input vs timeline ownership on view/pan channels**  
   Evidence: Plan/Cutaway must toggle `PlanBody`/`CutBody` opacity while intro animates reveals; Drawing pan/zoom owns position/scale so intro framing cannot use those channels.  
   Cost: Extra `World` parent + separate TraceLayer; careful opacity ownership split.  
   Root cause: language/runtime exclusive writers (`OVERLAPPING_WRITERS`) — correct contract, high authoring cost.  
   Workaround: timeline owns Trace/walls/furnishings/`World`; input owns Drawing transform and view opacities.

2. **Faithful cutaway without animated spatial layers**  
   Evidence: registry `space.planar25d` forbids animated spatial camera/hinge in this release; stills show oblique extrusions.  
   Cost: duplicated plan/cut geometry and hand parallelograms.  
   Root cause: language capability gap for animated 2.5D.  
   Workaround: 2D oblique walls + lowered front wall.

3. **Gesture model vs director pan/select/zoom**  
   Evidence: `input.bindings` restrictions — no pinch, no pointer-centred zoom, `dragTranslate` moves only the interact target.  
   Cost: UX shortfall vs brief; duplicated room hit targets on plan and cutaway.  
   Root cause: capability scope (not an implementation bug).  
   Workaround: slab pan + room clicks + keyboard; document gaps.

4. **Nested id / operators placement**  
   Evidence: nested `operators` rejected; after wrapping `World`, all `Drawing.*` references broke until rewritten to `World.Drawing.*`.  
   Cost: compile failures and bulk path rewrite.  
   Root cause: operators are top-level declarations; dotted ids must include full ancestry.  
   Workaround: root `operators World.Drawing…`; mechanical path update.

5. **Camera vs screen chrome**  
   Evidence: first camera tracks shifted title/UI off-frame (`still-4_7` before fix).  
   Cost: one rework cycle.  
   Root cause: implementation choice (scene camera affects all nodes); not a renderer defect.  
   Workaround: intro framing on `World` only.

---

## 3. Improvements

### Easier implementation (authoring / tooling / host)

| Improvement | Removes from this program | Enables | Kind / status |
| --- | --- | --- | --- |
| **Input overlay + timeline composition helpers** (documented patterns / lints for ownership) | Trial compiles hitting `OVERLAPPING_WRITERS`; manual World/Drawing split reasoning | Safer surface intros with pan/zoom | Tooling/docs; hypothesis — related to E007 ownership |
| **Shared CanvasRenderer still + InputSession harness** | Bespoke CDP verify script | Repeatable beat + click evidence | Tooling; recurs in blueprint/crane/circle retrospectives |
| **Screen-space / HUD layer** (ignore camera or parent to viewport) | Fear of camera eating chrome; World framing proxy | True camera moves with stable UI | Engine/Scene IR — **hypothesis**, needs design |
| **Named view states** (plan/cutaway) as first-class toggles | Dozens of mirrored `on click set … opacity` lines | Less error-prone mode switching | MotionScript or host — design decision |
| **Text entry / bound fields for assumptions** | Fake Revise toggle | Real revisable assumptions panel | Explicitly out of scope today (`input.bindings`) |

### More expressive results

| Improvement | Removes / replaces | Enables for this director script | Kind / status |
| --- | --- | --- | --- |
| **Animated spatial camera + hinge** on `space.planar25d` | Oblique parallelogram bank; World scale fake | True wall raise + three-quarter orbit while keeping plan topology | Scene IR/MotionScript — pending relative to 0.12 static spatial |
| **Pointer-centred zoom + pinch** | Origin-based scale steps | Director pan/zoom fidelity | `input.bindings` expansion — design decision |
| **Prefers-reduced-motion + interruptible sequences** | Host-seek documentation | Directed reducedMotion/onInterrupt | Timing/host contract — design decision |
| **Responsive layout / fluid viewport** | Fixed 1280×900 stack | True narrow adaptation | Not in registry — design decision |
| **Parametric plan / metre units** | Hand px conversion and duplicated plan/cut coords | Dimension edits that keep plan↔cutaway consistent | Language or authoring library — design decision; loops/functions need a decision per compatibility policy |

Existing released support already used: animated trim, input bindings, beats/timed keys, rounded rects, text. Pending `pending.md` items were **not** claimed. Historical `from-blueprint-to-home` evidence shows the same projection-duplication pain for film form; this surface adds interaction ownership friction on top.

---

## 4. Priority

**Fix / land first (high leverage, bounded):**

1. Documented ownership patterns + compiler diagnostics that name the conflicting writer for surface UIs.  
2. Shared still + InputSession verification harness (no language change).

**Bounded experiments:**

1. Animated spatial camera/hinge for one cutaway wall raise vs 2D extrusion (measure authoring lines and visual fidelity).  
2. Pointer-centred wheel zoom prototype behind `input.bindings` (or host-only) compared on this drawing.

**Defer:**

1. Full responsive layout engine.  
2. Free-text assumption editing (until text-entry input model exists).  
3. General loops/functions for plan generation (requires execution-model decision, not a routine syntax add).

---

*Stills and harness remain in scratch `/tmp/gvr-house-concept-blueprint/verify/`; only the three packaged files are the deliverable.*
