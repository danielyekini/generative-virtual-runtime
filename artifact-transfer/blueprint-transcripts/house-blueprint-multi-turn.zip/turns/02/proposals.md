Unevaluated implementation retrospective. These observations and proposals do not establish adopted capabilities or released support.

## 1. Result and fidelity

This is a directly authored native MotionScript **surface update**: a roof-off two-storey 3D cutaway of the assumed 12 × 10 m house, with icon-only HUD controls and no visible copy. It is not a film of an interface. The usable persistent result is the inspectable cutaway after the 1400 ms reveal (and immediately at t=1400 on seek / reduced-motion host skip).

### What matches the director’s intent

- **Form / operation / presentation:** `surface` + `update` + `transition`. Sequence duration 1400 ms; walls grow from the floor plates into a separated-storey cutaway; after `onEnd` the model remains interactive with no auto-orbit.
- **No visible text:** room labels, dimensions, schedules, assumptions, concept notice and control captions are absent from the painted surface. Opacity-0 name strings sit under the HUD as the closest native stand-in for accessible names (MotionScript `interact` has no aria-label field).
- **Palette:** navy background `#081b30`, cyan edges `#76d9ed`, white wall strokes, restrained blue wall/room fills.
- **Preserve:** same 12 × 10 m footprint (50 units/m; exterior face ~100…700 × 150…650); master + wet rooms + open LDK downstairs; four bedrooms + bath/linen/landing upstairs; stair void aligned between storeys; front/south entrance gap and rear/north garden opening.
- **Separated cutaway:** upper storey authored at spatial lift ≈ storey height + gap (255 units); assemble/separate via dual upper copies (parked copy opacity 0 + off-canvas y).
- **Icon controls:** separate, assemble, ground-only, upper-only, both, top-down plan twin, fit/reset, zoom ±. Keyboard aliases `s`/`a`/`1`/`2`/`0`/`t`/`r`/`=`/`-`. Focusable tab order 0…8. Drag on `World` pans (native click/drag threshold). Wheel on zoom-in steps scale.
- **Top-down:** non-spatial twin plans (`PlanView`) toggled against the 3D `World` group — a native approximation of a top-down camera switch without animated spatial cameras.

### Requirement / beat coverage (inspected)

| Path | Evidence |
| --- | --- |
| Reveal t=0 | CanvasRenderer PNG `stills/t0.png`, 1200×850, DPR 1: floor plates in elevated three-quarter; walls at scale 0; HUD present; no text. |
| Reveal mid | `t350.png`, `t700.png`, `t1050.png`: wall scales mid-growth; separated upper slab visible. |
| Reveal end / onEnd | `t1400.png`: full wall scales; separated cutaway; no auto rotation. |
| Assemble / separate | InputSession clicks at (108,48) and (48,48): `World.UpperAsm.opacity` 1→0, `position.y` 0↔−12000; re-evaluated frames. |
| Top-down / reset | Click (348,48) → `PlanView.opacity` 1; reset (408,48) → 0 and World restored. |
| Zoom | Click (468,48) → `World.scale` 1.1. |
| Reduced motion | No MS media-query binding. Approximated by seeking to 1400 ms (complete cutaway, no further growth). Host must skip 0…1400 to honour `reducedMotion` literally. |
| Interrupt | No native interrupt handler. Approximated by seeking to 1400 ms (complete model). Camera motion was never authored (unsupported), so there is none to cancel. |
| Trigger “when ready” | Approximated as program start — the dimensional revision *is* this program. No host event bridge. |
| Studio `.ms` open path | Code path confirmed: Split file accept includes `.ms` (`app/playground/src/player/main.ts`). Live Studio UI open was **not** re-run in this session after final hash; treated as unverified beyond the compile/runtime/CanvasRenderer evidence. |

### Approximations (visible consequences)

1. **Camera ease plan → three-quarter:** animated spatial camera channels are outside released `space.planar25d`. The camera is static at the final elevated three-quarter. “Ease from plan view” is approximated by walls growing under that fixed camera (floors look plan-like at t=0).
2. **Drag-to-orbit / touch orbit / pinch / pointer-centred wheel zoom:** `input.bindings` only offers `dragTranslate`, `set`/`toggle`/`step` on position/rotation/scale/opacity. Continuous orbit is **not** claimed. Drag pans the model in plane space; wheel zoom is uniform scale about authored origin, not gesture centre; pinch/two-finger pan are unsupported (single capture).
3. **Direct manipulation taking over presentation motion:** wall scale tracks finish at 1400 ms; input does not write those channels. Mid-intro drag does not cancel growth (would need interrupt/seek or exclusive ownership redesign).
4. **Accessible names:** opacity-0 text nodes are not wired into a platform accessibility tree by the runtime.
5. **Assemble height:** true spatial z animation unsupported; assemble swaps a second upper copy at z=storey height via opacity/position parking. Parked surfaces still generate `SPATIAL_NEAR_CULLED` diagnostics while present in the layer.
6. **Base program:** runtime state supplied the single-storey three-bedroom `.ms`, while chat history described an intermediate two-storey update that was not provided as source. The two-storey room arrangement was reconstructed from that director intent + preserve list (material assumption).

### Wrong / unsupported / unverified

- Continuous drag orbit, pinch, two-finger pan, pointer-centred zoom: **unsupported** in standalone MS (not faked with a host sidecar).
- Animated spatial camera / surface z / hinge: **unsupported** (registry).
- Host `prefers-reduced-motion` and interrupt hooks: **not in language**; seek used in verification only.
- Narrow responsive layout: fixed 1200×850 viewport (mandatory positive duration + fixed viewport).
- Live Studio file-open after final hash: **unverified this session**.
- Full furniture legibility at all yaw angles: only one static camera; back faces / openings can hide rooms.
- `RUNTIME_DEGRADED` diagnostics remain at every sampled time (near-cull of parked assemble copy; occasional surface intersection reports during growth).

### Material design assumptions

- Storey height 2.70 m (135 units); separation gap 2.40 m (120); wall thickness diagrammatic.
- Master left; ensuite and guest WC on wet stack; open LDK to rear/right; upstairs Bed2–5, shared bath, linen, landing over stair.
- Stair is a plan void + tread marks, not a 3D flight of risers.
- Roof omitted as directed; no site/structure compliance claim.

### Baseline measurements and provenance

- Repository commit: `a4d84b189ad4d533f1c4523c5a999cc22b594919` (worktree had unrelated local changes; no repository files were modified for this experiment).
- Releases: MotionScript **0.26.0**, Scene IR **0.25.0**, wire family **0.2**.
- Capability pins used: `space.planar25d`, `input.bindings`.
- Program: **608 lines**, **36011** UTF-8 bytes, SHA-256 `096f904e33b2463c69e56d567563ee18d5a1b29e7c88d229ddf5dee52dc39cd7`.
- Scene: **163** nodes, **97** spatial surfaces, **45** tracks / **90** keyframe values, **0** steps, **9** interaction targets.
- Limits: nodes 163/2000; surfaces 97/1024; tracks 45/1000; duration 1400/60000 ms; source ≪ 4 MiB.
- Environment: darwin, Node v24.10.0, Google Chrome 157.0.8103.38 (see `verify-report.json` in scratch).
- Compile (30 samples after 5 warmups): mean **27.42 ms** (min 24.13, max 69.55).
- Evaluate (200 samples, alt 0/1400 ms + input overlay): mean **0.771 ms/frame**.
- Render: full page capture (compile+eval+render) mean **26.7 ms** over 15 samples — **not** render-only; labelled estimate.
- Authored effort: not tracked.

Verification (scratch, not in ZIP): `compileMotionScript` + `validateSceneIR` (zero source diagnostics) + `AnimationRuntime` + Vite/CDP production `CanvasRenderer` stills at 0/350/700/1050/1400 ms. Runtime `RUNTIME_DEGRADED` near-cull diagnostics from the parked assemble copy are recorded above.

## 2. Hardest and most error-prone aspects, ranked

1. **Orbit and camera motion under frozen spatial cameras — language limitation.** Evidence: registry `space.planar25d` explicitly excludes animated spatial camera/z/hinge; `input.bindings` has no yaw/pitch writers. Cost: director’s primary manipulation affordance unmet. Workaround: static three-quarter camera + pan/zoom; honest non-claim of orbit.

2. **Dual-storey z without animated spatial channels — language limitation + authoring cost.** Evidence: two full upper assemblies, opacity+y parking, 97 surfaces, near-cull diagnostics. Workaround: assemble/separate clicks flip opacity and y as measured.

3. **Partition / wall hinge authoring — implementation error risk.** Early short hinge segments produced floating panels (inspected stills). Root cause: hinge lines must match plan bases while height lives in the pre-hinge rectangle axis. Workaround: redraw partitions and re-render.

4. **Wall growth vs input ownership — language/contract friction.** Tracks exclusively own wall `scale.*`; interrupt cannot “finish now” without seek.

5. **Verification harness friction — tooling gap.** Custom Vite/CDP page required; render-only timing hard without shared capture helper.

## 3. Improvements

### Easier implementation

| Change | Removes / enables | Status |
| --- | --- | --- |
| Shared artefact verifier (compile→validate→eval→CanvasRenderer→input→hash→ZIP) | Scratch CDP duplication | Tooling; recurs in prior blueprint proposals |
| Spatial camera + surface z/hinge as track **and** input channels | Static-camera and dual-copy workarounds | Deferred in 0.12 notes; needs design + conformance |
| `dragOrbit` / pinch / wheel-about-point actions | Pan-as-orbit lie; host sidecars | Not released; multi-touch out of 0.10 scope |
| Accessible `name` / `ariaLabel` on `interact` | Opacity-0 text hack | Not in grammar |
| Duration-free surfaces + reduced-motion / interrupt hooks | Seek approximations | Host+IR design |
| Drawable symbols for repeated wall segments | Duplicated UpperSep/UpperAsm banks | Historical recurrence; loops/functions need an execution-model decision |

### More expressive results

| Change | Enables for this director script |
| --- | --- |
| Animated spatial camera | True plan→three-quarter ease; user orbit without N× geometry |
| Animated surface z | Single upper storey lifting; assemble without dual copies |
| Seams / wall extrusion helpers | Continuous façades with openings |
| Lighting / soft shade | Clearer room vs wall legibility |

## 4. Priority

1. **First:** bounded experiment for **animated spatial camera + input orbit** (motivated by Home/crane and this script).
2. **Next:** surface **z/hinge animation** and a shared verifier.
3. **Defer:** general loops/functions, mesh solids/lighting backends, architectural solvers.

Hypotheses above are untested as product changes; this ZIP does not alter registry, releases or packages.
